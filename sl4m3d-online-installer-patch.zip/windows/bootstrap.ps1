param(
    [Parameter(Mandatory = $true)]
    [string]$InstallDir
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$AssetUrl = 'https://github.com/sl4m3d/sl4m3d-signer/releases/latest/download/windows-payload.zip'
$TempRoot = Join-Path $env:TEMP ("sl4m3d-signer-" + [guid]::NewGuid().ToString('N'))
$ZipPath = Join-Path $TempRoot 'windows-payload.zip'
$ExtractPath = Join-Path $TempRoot 'extracted'

try {
    New-Item -ItemType Directory -Force -Path $TempRoot, $ExtractPath, $InstallDir | Out-Null

    Invoke-WebRequest `
        -Uri $AssetUrl `
        -OutFile $ZipPath `
        -UseBasicParsing `
        -Headers @{ 'User-Agent' = 'sl4m3d-signer-installer' }

    if (!(Test-Path $ZipPath) -or (Get-Item $ZipPath).Length -lt 1MB) {
        throw 'GitHub lieferte kein gültiges Windows-Paket.'
    }

    Expand-Archive -LiteralPath $ZipPath -DestinationPath $ExtractPath -Force

    $AppExe = Get-ChildItem $ExtractPath -Filter 'sl4m3d Signer.exe' -Recurse |
        Select-Object -First 1
    if (!$AppExe) {
        throw 'Die Anwendung wurde im heruntergeladenen Paket nicht gefunden.'
    }

    Get-ChildItem -LiteralPath $InstallDir -Force -ErrorAction SilentlyContinue |
        Remove-Item -Recurse -Force

    Get-ChildItem -LiteralPath $AppExe.Directory.FullName -Force |
        Copy-Item -Destination $InstallDir -Recurse -Force

    if (!(Test-Path (Join-Path $InstallDir 'sl4m3d Signer.exe'))) {
        throw 'Die Anwendung konnte nicht vollständig installiert werden.'
    }
}
finally {
    if (Test-Path $TempRoot) {
        Remove-Item $TempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
