#define MyAppName "sl4m3d Signer"
#define MyAppVersion "1.2.0"
#define MyAppPublisher "sl4m3d"
#define MyAppExeName "sl4m3d Signer.exe"

[Setup]
AppId={{A30C6DE7-AC59-46A1-AC37-0C79C379A12B}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\sl4m3d Signer
DefaultGroupName=sl4m3d Signer
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=output
OutputBaseFilename=installer
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\{#MyAppExeName}
ArchitecturesInstallIn64BitMode=x64compatible
Uninstallable=yes

[Files]
Source: "bootstrap.ps1"; DestDir: "{tmp}"; Flags: deleteafterinstall

[Icons]
Name: "{autoprograms}\sl4m3d Signer"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\sl4m3d Signer"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Desktop-Verknüpfung erstellen"; GroupDescription: "Zusätzliche Verknüpfungen:"

[UninstallDelete]
Type: filesandordirs; Name: "{app}"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "sl4m3d Signer starten"; Flags: nowait postinstall skipifsilent

[Code]
procedure CurStepChanged(CurStep: TSetupStep);
var
  ResultCode: Integer;
  ScriptPath: String;
  Params: String;
begin
  if CurStep = ssPostInstall then
  begin
    ScriptPath := ExpandConstant('{tmp}\bootstrap.ps1');
    Params := '-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' +
      ScriptPath + '" -InstallDir "' + ExpandConstant('{app}') + '"';

    if not Exec(
      ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe'),
      Params,
      '',
      SW_HIDE,
      ewWaitUntilTerminated,
      ResultCode
    ) then
      RaiseException('Der GitHub-Download konnte nicht gestartet werden.');

    if ResultCode <> 0 then
      RaiseException('Der Download oder die Installation ist fehlgeschlagen. Prüfe deine Internetverbindung und starte den Installer erneut.');
  end;
end;
