$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

python -m pip install --upgrade pip
python -m pip install -r windows/requirements-build.txt

$OpenSslCommand = Get-Command openssl -ErrorAction Stop
$OpenSslCandidates = @(
    'C:\Program Files\OpenSSL-Win64\bin\openssl.exe',
    'C:\Program Files\OpenSSL\bin\openssl.exe'
)
$OpenSslExe = $OpenSslCandidates |
    Where-Object { Test-Path $_ } |
    Select-Object -First 1

if (!$OpenSslExe) {
    # Chocolatey may expose a shim on PATH; search its installed package files.
    $ChocolateyLib = Join-Path $env:ChocolateyInstall 'lib'
    $OpenSslExe = Get-ChildItem $ChocolateyLib -Filter 'openssl.exe' -Recurse -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -match 'OpenSSL|openssl' -and $_.FullName -notmatch '\\shims?\\' } |
        Select-Object -ExpandProperty FullName -First 1
}
if (!$OpenSslExe) {
    throw 'Could not locate the actual OpenSSL installation directory.'
}
$OpenSslBin = Split-Path -Parent $OpenSslExe
$OpenSslHome = Split-Path -Parent $OpenSslBin

if (Test-Path 'build') { Remove-Item 'build' -Recurse -Force }
if (Test-Path 'dist') { Remove-Item 'dist' -Recurse -Force }
if (Test-Path 'windows/output') { Remove-Item 'windows/output' -Recurse -Force }
New-Item -ItemType Directory -Force -Path 'windows/output' | Out-Null

pyinstaller --noconfirm --clean --windowed --onedir `
  --name 'sl4m3d Signer' `
  --add-data 'linux\source-portable\app\assets;assets' `
  linux\source-portable\app\src\signer.py

$Dist = Join-Path (Get-Location) 'dist\sl4m3d Signer'
if (!(Test-Path (Join-Path $Dist 'sl4m3d Signer.exe'))) {
    throw 'PyInstaller application executable missing.'
}

# Bundle only the OpenSSL runtime pieces used by the app, not headers/docs/dev files.
$OpenSslTarget = Join-Path $Dist 'openssl'
$OpenSslTargetBin = Join-Path $OpenSslTarget 'bin'
$OpenSslModules = Join-Path $OpenSslTargetBin 'ossl-modules'
$OpenSslSsl = Join-Path $OpenSslTarget 'ssl'
New-Item -ItemType Directory -Force -Path $OpenSslTargetBin, $OpenSslModules, $OpenSslSsl | Out-Null

Copy-Item $OpenSslExe $OpenSslTargetBin -Force

$CryptoDll = Get-ChildItem $OpenSslBin -Filter 'libcrypto-3-*.dll' | Select-Object -First 1
$SslDll = Get-ChildItem $OpenSslBin -Filter 'libssl-3-*.dll' | Select-Object -First 1
if (!$CryptoDll -or !$SslDll) {
    throw 'OpenSSL runtime DLLs libcrypto-3-*.dll and libssl-3-*.dll were not found.'
}
Copy-Item $CryptoDll.FullName $OpenSslTargetBin -Force
Copy-Item $SslDll.FullName $OpenSslTargetBin -Force

$LegacyModule = Join-Path $OpenSslHome 'lib\ossl-modules\legacy.dll'
if (!(Test-Path $LegacyModule)) {
    $LegacyModule = Join-Path $OpenSslBin 'ossl-modules\legacy.dll'
}
if (Test-Path $LegacyModule) {
    Copy-Item $LegacyModule $OpenSslModules -Force
}

$ConfigCandidates = @(
    (Join-Path $OpenSslHome 'ssl\openssl.cnf'),
    (Join-Path $OpenSslBin 'openssl.cnf')
)
$Config = $ConfigCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($Config) {
    Copy-Item $Config (Join-Path $OpenSslSsl 'openssl.cnf') -Force
}

$Payload = Join-Path (Get-Location) 'windows\output\windows-payload.zip'
Compress-Archive -Path (Join-Path $Dist '*') -DestinationPath $Payload -CompressionLevel Optimal -Force

$Iscc = Get-Command ISCC.exe -ErrorAction SilentlyContinue
if (!$Iscc) { $Iscc = Get-Command ISCC -ErrorAction SilentlyContinue }
if (!$Iscc) { throw 'Inno Setup 6 (ISCC.exe) is required.' }

& $Iscc.Source 'windows\installer.iss'
if ($LASTEXITCODE -ne 0) { throw "Inno Setup failed with exit code $LASTEXITCODE" }

$Installer = Join-Path (Get-Location) 'windows\output\installer.exe'
if (!(Test-Path $Installer)) { throw 'Online installer EXE was not generated.' }

$Size = (Get-Item $Installer).Length
Write-Host "Online installer size: $([math]::Round($Size / 1MB, 2)) MB"
Write-Host "Payload size: $([math]::Round((Get-Item $Payload).Length / 1MB, 2)) MB"
Write-Host "BUILT: $Installer"
Write-Host "BUILT: $Payload"
